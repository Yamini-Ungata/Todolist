import { useState } from "react";
import TodoInput from "./TodoInput";
import TodoList from "./TodoList";
import "./todo.css";

function Tasks() {
  const [tasks, setTasks] = useState([]); // Stores tasks
  const [selectedTask, setSelectedTask] = useState(null); // Stores selected task index
  const [isEditing, setIsEditing] = useState(false); // Track edit mode
  const [inputValue, setInputValue] = useState(""); // Store input value separately

  // Add a task
  const addTask = (task) => {
    if (task.trim()) {
      setTasks([...tasks, task]);
      setInputValue(""); // Clear input field
    }
  };

  // Remove selected task
  const removeTask = () => {
    if (selectedTask !== null) {
      setTasks(tasks.filter((_, index) => index !== selectedTask));
      setSelectedTask(null);
      setIsEditing(false);
      setInputValue(""); // Clear input field
    }
  };

  // Start editing (loads selected task into input)
  const startEditing = () => {
    if (selectedTask !== null) {
      setIsEditing(true);
      setInputValue(tasks[selectedTask]); // Load selected task into input box
    }
  };

  // Update task
  const updateTask = () => {
    if (selectedTask !== null && inputValue.trim() !== "") {
      let updatedTasks = [...tasks];
      updatedTasks[selectedTask] = inputValue;
      setTasks(updatedTasks);
      setSelectedTask(null);
      setIsEditing(false);
      setInputValue(""); // Clear input field
    }
  };

  // Toggle selection (Now also updates input field when editing)
  const toggleSelection = (index) => {
    if (selectedTask === index) {
      setSelectedTask(null);
    } else {
      setSelectedTask(index);
      if (isEditing) setInputValue(tasks[index]); // Set input when editing
    }
  };

  return (
    <div className="todo-container">
      <h2>To-Do List</h2>
      <TodoInput
        addTask={addTask}
        updateTask={updateTask}
        isEditing={isEditing}
        inputValue={inputValue}
        setInputValue={setInputValue}
      />
      <TodoList tasks={tasks} selectedTask={selectedTask} toggleSelection={toggleSelection} />
      <button onClick={removeTask} disabled={selectedTask === null}>
        Remove
      </button>
      <button onClick={startEditing} disabled={selectedTask === null}>
        Edit
      </button>
    </div>
  );
}

export default Tasks;
