function TodoInput({ addTask, updateTask, isEditing, inputValue, setInputValue }) {
    const handleSubmit = () => {
      if (inputValue.trim()) {
        isEditing ? updateTask(inputValue) : addTask(inputValue);
      }
    };
  
    return (
      <div>
        <input
          type="text"
          placeholder="Enter your task"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
        />
        <button onClick={handleSubmit}>{isEditing ? "Update" : "Add"}</button>
      </div>
    );
  }
  
  export default TodoInput;
  