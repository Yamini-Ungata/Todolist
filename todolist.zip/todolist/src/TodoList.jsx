function TodoList({ tasks, selectedTask, toggleSelection }) {
    return (
      <ul>
        {tasks.map((task, index) => (
          <li
            key={index}
            className={selectedTask === index ? "selected-task" : ""}
            onClick={() => toggleSelection(index)}
          >
            {task}
          </li>
        ))}
      </ul>
    );
  }
  
  export default TodoList;
  