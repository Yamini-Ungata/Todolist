import Tasks from "./Tasks";
function App(){
  return(
    <Tasks/>
  );
}
export default App;